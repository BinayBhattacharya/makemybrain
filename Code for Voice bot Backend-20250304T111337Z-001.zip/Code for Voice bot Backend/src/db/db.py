import sqlite3
from dotenv import load_dotenv
import os

class DatabaseManager:
    def __init__(self):
        self.db_name = "kaira.db"
        self.connection = None
        self.cursor = None
        self.connect()
        load_dotenv()
        self.chaplusi_one = os.getenv("chaplusi_one")
        self.chaplusi_two = os.getenv("chaplusi_two")


    def connect(self):
        self.connection = sqlite3.connect(self.db_name)
        self.cursor = self.connection.cursor()

    def disconnect(self):
        if self.connection:
            self.connection.commit()
            self.connection.close()
            self.connection = None
            self.cursor = None

    def create_tables(self):
        # Create the first table
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS KairaReply (
                id INTEGER PRIMARY KEY,
                userID TEXT UNIQUE,
                reply TEXT
            )
        ''')

        # Create the second table
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS Chaplusi (
                id INTEGER PRIMARY KEY,
                userID TEXT UNIQUE,
                reply TEXT,
                count INTEGER DEFAULT 0
            )
        ''')

    def insert_data_into_KairaReply(self, userID, reply):
        self.cursor.execute('''
            INSERT OR REPLACE INTO KairaReply (userID, reply)
            VALUES (?, ?)
        ''', (userID, reply))

    def insert_data_into_Chaplusi(self, userID, reply):
        self.cursor.execute('''
        SELECT COUNT(*) FROM Chaplusi
        WHERE userID = ?
        ''', (userID,))
        row_count = self.cursor.fetchone()[0]
        count=max(0,row_count)
        self.cursor.execute('''
            INSERT OR REPLACE INTO Chaplusi (userID, reply, count)
            VALUES (?, ?, ?)
        ''', (userID, reply, count))

    def read_data_from_KairaReply(self):
        self.cursor.execute('SELECT * FROM KairaReply')
        data = self.cursor.fetchall()
        return data

    def read_data_from_Chaplusi(self):
        self.cursor.execute('SELECT * FROM Chaplusi')
        data = self.cursor.fetchall()
        return data
    
    def get_KairaReply(self, userID):
        self.cursor.execute('''
            SELECT reply FROM KairaReply
            WHERE userID = ?
        ''', (userID,))
        data = self.cursor.fetchone()
        return data[0] if data else None
    
    def get_Chaplusi(self, userID):
        self.cursor.execute('''
            SELECT reply, count FROM Chaplusi
            WHERE userID = ?
        ''', (userID,))
        data = self.cursor.fetchone()
        if data:
            count=data[1]
            if(count == 0):
                return self.chaplusi_two
        if data:
            return data[0]
        else:
            self.insert_data_into_Chaplusi(userID,self.chaplusi_one)
            return self.chaplusi_one
