import requests
from dotenv import load_dotenv
import os
from src.db.db import DatabaseManager

class Kaira:
    def __init__(self):
        load_dotenv()
        self.openrouter_api_key = os.getenv("openrouter_api_key")
        self.your_site_url = os.getenv("your_site_url")
        self.your_site_name = os.getenv("your_site_name")

    def GetReply(self,messages):
        api_url = "https://openrouter.ai/api/v1/chat/completions"

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.openrouter_api_key}",
            "HTTP-Referer": self.your_site_url,
            "X-Title": self.your_site_name,
        }

        payload = {
            # "model": "meta-llama/llama-2-13b-chat",
            "model":"openai/gpt-3.5-turbo",
            "messages": messages
        }

        response = requests.post(api_url, headers=headers, json=payload)

        if response.status_code == 200:
            response=response.json()
            response=dict(response)
            response=response['choices'][0]['message']['content']
            return response
        else:
            print(f"Error: {response.status_code}")
            print(response.text)
            return None

    def SaveKairaReply(self, userID, reply, db_manager):
        db_manager.insert_data_into_KairaReply(userID,reply)

    def KairaThread(self,messages_for_kaira,userID):
        bot_reply = self.GetReply(messages_for_kaira)
        print("-- ",bot_reply)
        db_manager=DatabaseManager()
        self.SaveKairaReply(userID,bot_reply,db_manager)
        db_manager.disconnect()