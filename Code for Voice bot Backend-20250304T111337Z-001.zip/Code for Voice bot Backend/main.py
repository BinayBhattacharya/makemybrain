from flask import Flask, render_template, request
from flask_cors import CORS
import os
from src.db.db import DatabaseManager
import threading
from src.utils.Chaplusi import Chaplusi
from src.utils.Kaira import Kaira

db_manager_temp = DatabaseManager()
db_manager_temp.create_tables()
db_manager_temp.disconnect()

app = Flask(__name__)
CORS(app)

# Database locking

@app.route('/test', methods=['GET'])
def test():
    return "Kaira backend live"

#user stopped speaking
#Res - chaplusi
@app.route('/kaira/t1/', methods=['GET', 'POST'])
def requestTypeOne():
    if request.method == 'GET':
        return "Request type unavailable"
    elif request.method == 'POST':
        reqBody = request.json 
        messages = reqBody.get('messages', [])
        userID = reqBody.get('userID', None)
        #TODO : validate the body and send 503
        kaira= Kaira()
        thread = threading.Thread(target=kaira.KairaThread, args=(messages, userID))
        thread.start()
        db_manager = DatabaseManager()
        chaplusi = db_manager.get_Chaplusi(userID)
        db_manager.disconnect()
        return chaplusi
    else:
        return "Request type unavailable"


#Chaplusi rendered
#Res - KairaReply
@app.route('/kaira/t2/', methods=['GET', 'POST'])
def requestTypeTwo():
    if request.method == 'GET':
        return "Request type unavailable"
    elif request.method == 'POST':
        reqBody = request.json 
        messages = reqBody.get('messages', [])
        userID = reqBody.get('userID', None)
        #TODO : validate the body and send 503
        chaplusi= Chaplusi()
        thread = threading.Thread(target=chaplusi.ChaplusiThread, args=(messages, userID))
        thread.start()
        db_manager = DatabaseManager()
        kaira_reply = db_manager.get_KairaReply(userID)
        # print(kaira_reply)
        db_manager.disconnect()
        return kaira_reply
    else:
        return "Request type unavailable"

if __name__ == '__main__':
    app.run(debug=True)
